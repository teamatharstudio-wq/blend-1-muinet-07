import "server-only";
import { db } from "@/lib/db";
import { publicProjectWhere, sitemapProjectWhere, isPubliclyReachable } from "@/lib/visibility";

// Fields safe to send to an unauthenticated visitor. Notably excludes
// passwordHash, activityLog, versions, and internal-only fields.
const PUBLIC_PROJECT_SELECT = {
  id: true,
  slug: true,
  title: true,
  titleAccent: true,
  category: { select: { id: true, name: true } },
  year: true,
  software: true,
  client: true,
  video: true,
  status: true,
  visibility: true,
  scheduledAt: true,
  featured: true,
  featuredOrder: true,
  description: true,
  cover: { select: { id: true, url: true, name: true } },
  gallery: {
    select: { id: true, position: true, media: { select: { id: true, url: true, name: true } } },
    orderBy: { position: "asc" as const },
  },
  links: { select: { id: true, label: true, url: true } },
  tags: true,
  seoTitle: true,
  seoDescription: true,
  closedMessage: true,
  // passwordHash intentionally omitted — see getPasswordProtectedProject below
} as const;

export async function listPublicProjects(opts: { category?: string; featuredOnly?: boolean } = {}) {
  return db.project.findMany({
    where: {
      ...publicProjectWhere(),
      ...(opts.category ? { category: { name: opts.category } } : {}),
      ...(opts.featuredOnly ? { featured: true } : {}),
    },
    select: PUBLIC_PROJECT_SELECT,
    orderBy: [{ featuredOrder: "asc" }, { createdAt: "desc" }],
  });
}

/**
 * Fetch a single project by slug for the public detail page.
 * Returns null for anything not publicly reachable (draft/review/private/
 * trashed/archived/closed-without-message, or not-yet-due scheduled) —
 * the caller gets a 404, never a partial or gated payload, unless the
 * project is PASSWORD_PROTECTED, in which case the description/gallery/
 * files are stripped until lib/actions/password-gate.ts verifies the
 * password server-side.
 */
export async function getPublicProjectBySlug(slug: string) {
  const project = await db.project.findFirst({
    where: { slug, ...publicProjectWhere() },
    select: { ...PUBLIC_PROJECT_SELECT, files: { select: { id: true, name: true, url: true, size: true } } },
  });

  if (!project || !isPubliclyReachable(project)) return null;

  if (project.visibility === "PASSWORD_PROTECTED") {
    // Strip the gated content; the page renders a password form instead.
    // The actual unlock happens via a Server Action that re-fetches with
    // the password check applied server-side — see lib/actions/password-gate.ts.
    const { description, gallery, files, ...rest } = project;
    return { ...rest, description: null, gallery: [], files: [], locked: true as const };
  }

  return { ...project, locked: false as const };
}

/** For app/sitemap.ts — indexable projects only, minimal fields. */
export async function listSitemapProjects() {
  return db.project.findMany({
    where: sitemapProjectWhere(),
    select: { slug: true, updatedAt: true },
  });
}
