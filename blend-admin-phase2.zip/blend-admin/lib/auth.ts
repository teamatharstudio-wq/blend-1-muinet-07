import NextAuth, { type NextAuthConfig } from "next-auth";
import Credentials from "next-auth/providers/credentials";
import { PrismaAdapter } from "@auth/prisma-adapter";
import bcrypt from "bcryptjs";
import { db } from "./db";
import type { Role } from "@prisma/client";

/**
 * Real, server-verified authentication.
 *
 *  - Credentials are checked against a bcrypt hash stored in Postgres
 *    (User.passwordHash), compared server-side with bcrypt.compare.
 *    The plaintext password never touches storage and the hash never
 *    leaves the server.
 *  - Sessions are database-backed (Prisma adapter) and shipped to the
 *    browser only as a secure, httpOnly, sameSite session cookie —
 *    there is no client-readable "isAdmin" flag anywhere in this app.
 *    Every privileged read/write re-verifies the session on the server.
 */
export const authConfig: NextAuthConfig = {
  adapter: PrismaAdapter(db),
  session: { strategy: "database", maxAge: 30 * 24 * 60 * 60 }, // 30 days
  pages: { signIn: "/login" },
  cookies: {
    sessionToken: {
      name: "__Host-blend-admin-session",
      options: {
        httpOnly: true,
        sameSite: "lax",
        path: "/",
        secure: process.env.NODE_ENV === "production",
      },
    },
  },
  providers: [
    Credentials({
      name: "Email and password",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        const email = String(credentials?.email || "")
          .trim()
          .toLowerCase();
        const password = String(credentials?.password || "");
        if (!email || !password) return null;

        // Deliberately generic errors below (no "email not found" vs
        // "wrong password" distinction) to avoid user enumeration.
        const user = await db.user.findUnique({ where: { email } });
        if (!user) return null;

        const valid = await bcrypt.compare(password, user.passwordHash);
        if (!valid) return null;

        await db.user.update({
          where: { id: user.id },
          data: { lastLoginAt: new Date() },
        });

        return { id: user.id, email: user.email, name: user.name, role: user.role };
      },
    }),
  ],
  callbacks: {
    async session({ session, user }) {
      // `user` comes from the DB session lookup on every request — this is
      // not client-supplied data, so it's safe to trust the role here.
      if (session.user) {
        (session.user as { id: string; role: Role }).id = user.id;
        (session.user as { id: string; role: Role }).role = (user as { role: Role }).role;
      }
      return session;
    },
  },
};

export const { handlers, auth, signIn, signOut } = NextAuth(authConfig);

/**
 * Server-side helper: returns the verified session or throws.
 * Use at the top of any Server Action / Route Handler that requires login.
 */
export async function requireSession() {
  const session = await auth();
  if (!session?.user) {
    throw new Error("Unauthorized: no active session");
  }
  return session as typeof session & { user: { id: string; role: Role; email: string } };
}
