import type { Role } from "@prisma/client";

/**
 * RBAC — single source of truth for what each role can do.
 *
 * Rules from the spec:
 *  - Owner: full access, including Users & Settings.
 *  - Editor: manage content (Projects, Categories, Media, Messages, Blog),
 *    but no user management and no settings management.
 *  - Viewer: read-only everywhere.
 *
 * This module has NO knowledge of cookies/sessions/requests — it is pure
 * role -> permission logic, so it can be unit tested and reused identically
 * from Server Components, Server Actions, Route Handlers, and middleware.
 * Every mutation in the app must call `can()` (or `requireRole`) with the
 * caller's role loaded from the verified server-side session — never a
 * role value read from the client.
 */

export type Permission =
  | "content:read"
  | "content:write" // projects, categories, media, messages, blog CRUD
  | "content:trash"
  | "users:read"
  | "users:write"
  | "settings:read"
  | "settings:write"
  | "logs:read"
  | "backups:read"
  | "backups:write";

const ROLE_PERMISSIONS: Record<Role, Permission[]> = {
  OWNER: [
    "content:read",
    "content:write",
    "content:trash",
    "users:read",
    "users:write",
    "settings:read",
    "settings:write",
    "logs:read",
    "backups:read",
    "backups:write",
  ],
  EDITOR: ["content:read", "content:write", "content:trash", "logs:read"],
  VIEWER: ["content:read", "logs:read", "settings:read"],
};

export function can(role: Role, permission: Permission): boolean {
  return ROLE_PERMISSIONS[role]?.includes(permission) ?? false;
}

/**
 * Throws if the role lacks the permission. Use at the top of every Server
 * Action / Route Handler that mutates data:
 *
 *   const session = await requireSession();
 *   requirePermission(session.user.role, "content:write");
 */
export class ForbiddenError extends Error {
  constructor(permission: Permission) {
    super(`Forbidden: missing permission "${permission}"`);
    this.name = "ForbiddenError";
  }
}

export function requirePermission(role: Role, permission: Permission): void {
  if (!can(role, permission)) throw new ForbiddenError(permission);
}
