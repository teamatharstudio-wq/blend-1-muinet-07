"use server";

import { db } from "@/lib/db";
import { verifyPassword } from "@/lib/passwords";
import { checkRateLimit } from "@/lib/rate-limit";
import { headers } from "next/headers";

/**
 * Verifies a visitor-supplied password for a PASSWORD_PROTECTED project.
 * Runs entirely server-side: the hash is fetched here and never sent to
 * the client, and the comparison happens here too. On success, returns the
 * full public project payload (the caller then renders it); on failure,
 * returns { ok: false } with no additional information.
 */
export async function unlockProject(slug: string, password: string) {
  const ip = (await headers()).get("x-forwarded-for") ?? "unknown";
  const rl = checkRateLimit(`password-gate:${ip}:${slug}`, { limit: 8, windowMs: 10 * 60 * 1000 });
  if (!rl.ok) {
    return { ok: false as const, reason: "rate_limited" as const };
  }

  const project = await db.project.findFirst({
    where: { slug, visibility: "PASSWORD_PROTECTED", status: "PUBLISHED", trashedAt: null },
    select: {
      passwordHash: true,
      id: true,
      title: true,
      description: true,
      gallery: { select: { id: true, media: { select: { url: true, name: true } } } },
      files: { select: { id: true, name: true, url: true } },
    },
  });

  if (!project || !project.passwordHash) {
    return { ok: false as const, reason: "invalid" as const };
  }

  const valid = await verifyPassword(password, project.passwordHash);
  if (!valid) {
    return { ok: false as const, reason: "invalid" as const };
  }

  const { passwordHash, ...safe } = project;
  return { ok: true as const, project: safe };
}
