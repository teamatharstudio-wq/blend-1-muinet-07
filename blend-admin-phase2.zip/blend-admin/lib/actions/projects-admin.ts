"use server";

import { db } from "@/lib/db";
import { requireSession } from "@/lib/auth";
import { requirePermission } from "@/lib/rbac";
import { hashPassword } from "@/lib/passwords";
import { revalidatePath } from "next/cache";
import type { ProjectStatus, ProjectVisibility } from "@prisma/client";

async function logActivity(params: {
  projectId: string;
  userId: string;
  action: string;
  prevStatus?: string | null;
  newStatus?: string | null;
}) {
  await db.activityLogEntry.create({
    data: {
      entityType: "project",
      entityId: params.projectId,
      action: params.action,
      prevStatus: params.prevStatus ?? null,
      newStatus: params.newStatus ?? null,
      userId: params.userId,
      projectId: params.projectId,
    },
  });
}

async function snapshotVersion(projectId: string, note: string) {
  const current = await db.project.findUniqueOrThrow({ where: { id: projectId } });
  await db.versionSnapshot.create({
    data: { entityType: "project", entityId: projectId, projectId, note, snapshot: current as unknown as object },
  });
}

/** Server-side slug uniqueness check, called from the editor before submit. */
export async function checkSlugAvailable(slug: string, excludeId?: string) {
  const existing = await db.project.findFirst({ where: { slug, NOT: excludeId ? { id: excludeId } : undefined } });
  return { available: !existing };
}

export async function createProject(input: {
  title: string;
  slug: string;
  categoryId?: string;
  status?: ProjectStatus;
}) {
  const session = await requireSession();
  requirePermission(session.user.role, "content:write");

  const { available } = await checkSlugAvailable(input.slug);
  if (!available) throw new Error("Slug already in use");

  const project = await db.project.create({
    data: {
      title: input.title,
      slug: input.slug,
      categoryId: input.categoryId,
      status: input.status ?? "DRAFT",
    },
  });

  await logActivity({ projectId: project.id, userId: session.user.id, action: "created", newStatus: project.status });
  revalidatePath("/admin/projects");
  return project;
}

export async function updateProjectStatus(projectId: string, newStatus: ProjectStatus) {
  const session = await requireSession();
  requirePermission(session.user.role, "content:write");

  const before = await db.project.findUniqueOrThrow({ where: { id: projectId }, select: { status: true } });
  await snapshotVersion(projectId, `Before status change to ${newStatus}`);

  const updated = await db.project.update({ where: { id: projectId }, data: { status: newStatus } });

  await logActivity({
    projectId,
    userId: session.user.id,
    action: "statusChanged",
    prevStatus: before.status,
    newStatus,
  });

  revalidatePath("/admin/projects");
  revalidatePath(`/projects/${updated.slug}`);
  return updated;
}

/**
 * Sets or clears the password on a PASSWORD_PROTECTED project. The
 * plaintext password is accepted here (from an authenticated admin form
 * submission over HTTPS) and hashed immediately — it is never stored, and
 * the resulting hash is never included in any Server Action return value.
 */
export async function setProjectPassword(projectId: string, plaintextPassword: string | null) {
  const session = await requireSession();
  requirePermission(session.user.role, "content:write");

  const passwordHash = plaintextPassword ? await hashPassword(plaintextPassword) : null;

  await db.project.update({ where: { id: projectId }, data: { passwordHash } });
  await logActivity({
    projectId,
    userId: session.user.id,
    action: plaintextPassword ? "passwordSet" : "passwordCleared",
  });

  revalidatePath("/admin/projects");
  return { ok: true };
}

export async function setProjectVisibility(projectId: string, visibility: ProjectVisibility) {
  const session = await requireSession();
  requirePermission(session.user.role, "content:write");

  const updated = await db.project.update({ where: { id: projectId }, data: { visibility } });
  await logActivity({ projectId, userId: session.user.id, action: "visibilityChanged", newStatus: visibility });

  revalidatePath("/admin/projects");
  revalidatePath(`/projects/${updated.slug}`);
  return updated;
}

export async function trashProject(projectId: string) {
  const session = await requireSession();
  requirePermission(session.user.role, "content:trash");

  await db.project.update({ where: { id: projectId }, data: { trashedAt: new Date() } });
  await logActivity({ projectId, userId: session.user.id, action: "trashed" });

  revalidatePath("/admin/projects");
  return { ok: true };
}

export async function restoreProject(projectId: string) {
  const session = await requireSession();
  requirePermission(session.user.role, "content:trash");

  await db.project.update({ where: { id: projectId }, data: { trashedAt: null } });
  await logActivity({ projectId, userId: session.user.id, action: "restored" });

  revalidatePath("/admin/projects");
  return { ok: true };
}

export async function toggleFeatured(projectId: string, featured: boolean) {
  const session = await requireSession();
  requirePermission(session.user.role, "content:write");

  const updated = await db.project.update({ where: { id: projectId }, data: { featured } });
  await logActivity({ projectId, userId: session.user.id, action: featured ? "featured" : "unfeatured" });
  revalidatePath("/admin/projects");
  return updated;
}

export async function updateFeaturedOrder(orderedIds: string[]) {
  const session = await requireSession();
  requirePermission(session.user.role, "content:write");

  await db.$transaction(
    orderedIds.map((id, index) => db.project.update({ where: { id }, data: { featuredOrder: index } }))
  );
  revalidatePath("/admin/projects");
  return { ok: true };
}

export async function duplicateProject(projectId: string) {
  const session = await requireSession();
  requirePermission(session.user.role, "content:write");

  const original = await db.project.findUniqueOrThrow({
    where: { id: projectId },
    include: { links: true, gallery: true },
  });

  let slug = `${original.slug}-copy`;
  let n = 2;
  while (await db.project.findUnique({ where: { slug } })) {
    slug = `${original.slug}-copy-${n}`;
    n += 1;
  }

  const copy = await db.project.create({
    data: {
      title: `${original.title} (Copy)`,
      slug,
      titleAccent: original.titleAccent,
      categoryId: original.categoryId,
      year: original.year,
      software: original.software,
      client: original.client,
      video: original.video,
      status: "DRAFT",
      visibility: "PRIVATE",
      // passwordHash intentionally NOT copied — a duplicate never inherits
      // the original's password.
      closedMessage: original.closedMessage,
      description: original.description,
      coverId: original.coverId,
      tags: original.tags,
      seoTitle: original.seoTitle,
      seoDescription: original.seoDescription,
      links: { create: original.links.map((l) => ({ label: l.label, url: l.url })) },
      gallery: { create: original.gallery.map((g) => ({ mediaId: g.mediaId, position: g.position })) },
    },
  });

  await logActivity({ projectId: copy.id, userId: session.user.id, action: "duplicatedFrom:" + original.id });
  revalidatePath("/admin/projects");
  return copy;
}

export async function bulkUpdateCategory(projectIds: string[], categoryId: string) {
  const session = await requireSession();
  requirePermission(session.user.role, "content:write");

  await db.project.updateMany({ where: { id: { in: projectIds } }, data: { categoryId } });
  for (const projectId of projectIds) {
    await logActivity({ projectId, userId: session.user.id, action: "bulkCategoryChanged" });
  }
  revalidatePath("/admin/projects");
  return { ok: true };
}

export async function bulkAddTag(projectIds: string[], tag: string) {
  const session = await requireSession();
  requirePermission(session.user.role, "content:write");

  const projects = await db.project.findMany({ where: { id: { in: projectIds } }, select: { id: true, tags: true } });
  await db.$transaction(
    projects.map((p) =>
      db.project.update({
        where: { id: p.id },
        data: { tags: p.tags.includes(tag) ? p.tags : [...p.tags, tag] },
      })
    )
  );
  for (const projectId of projectIds) {
    await logActivity({ projectId, userId: session.user.id, action: "bulkTagAdded:" + tag });
  }
  revalidatePath("/admin/projects");
  return { ok: true };
}

export async function bulkTrash(projectIds: string[]) {
  const session = await requireSession();
  requirePermission(session.user.role, "content:trash");

  await db.project.updateMany({ where: { id: { in: projectIds } }, data: { trashedAt: new Date() } });
  for (const projectId of projectIds) {
    await logActivity({ projectId, userId: session.user.id, action: "trashed" });
  }
  revalidatePath("/admin/projects");
  return { ok: true };
}

/**
 * Permanently deletes a project. Only ever reachable from the Trash view
 * on an already-trashed project — see the spec's trashRetentionDays
 * setting for the intended automatic-purge policy (a scheduled job, not
 * built in this phase, would call this after the retention window).
 */
export async function permanentlyDeleteProject(projectId: string) {
  const session = await requireSession();
  requirePermission(session.user.role, "content:trash");

  const project = await db.project.findUniqueOrThrow({ where: { id: projectId }, select: { trashedAt: true } });
  if (!project.trashedAt) {
    throw new Error("Refusing to permanently delete a project that hasn't been trashed first");
  }

  await db.project.delete({ where: { id: projectId } });
  // Note: no activity-log entry references this project afterward since
  // the FK is onDelete: Cascade for ActivityLogEntry.projectId — the
  // action is instead logged against a null projectId for auditability.
  await db.activityLogEntry.create({
    data: { entityType: "project", entityId: projectId, action: "permanentlyDeleted", userId: session.user.id },
  });
  revalidatePath("/admin/projects");
  return { ok: true };
}

export async function getAdminProjectById(projectId: string) {
  const session = await requireSession();
  requirePermission(session.user.role, "content:read");

  const project = await db.project.findUniqueOrThrow({
    where: { id: projectId },
    include: {
      category: true,
      cover: true,
      gallery: { include: { media: true }, orderBy: { position: "asc" } },
      links: true,
      files: true,
    },
  });
  const { passwordHash, ...rest } = project;
  return { ...rest, hasPassword: !!passwordHash };
}

export async function getProjectActivityLog(projectId: string) {
  const session = await requireSession();
  requirePermission(session.user.role, "logs:read");
  return db.activityLogEntry.findMany({
    where: { entityType: "project", entityId: projectId },
    orderBy: { ts: "desc" },
    include: { user: { select: { id: true, name: true, email: true } } },
  });
}

export async function getProjectVersions(projectId: string) {
  const session = await requireSession();
  requirePermission(session.user.role, "content:read");
  return db.versionSnapshot.findMany({
    where: { entityType: "project", entityId: projectId },
    orderBy: { ts: "desc" },
  });
}

/** Restores a project's fields from a stored VersionSnapshot, snapshotting the current state first (so a restore is itself undoable). */
export async function restoreProjectVersion(projectId: string, versionId: string) {
  const session = await requireSession();
  requirePermission(session.user.role, "content:write");

  const version = await db.versionSnapshot.findUniqueOrThrow({ where: { id: versionId } });
  await snapshotVersion(projectId, "Before restore");

  const snap = version.snapshot as Record<string, unknown>;
  // Only restore plain scalar/enum fields present on the model — relations
  // (gallery/links/files) are intentionally left alone to avoid silently
  // orphaning media records; those are managed separately in the editor.
  const {
    id: _id,
    createdAt: _c,
    updatedAt: _u,
    passwordHash: _p,
    ...restorable
  } = snap;

  const updated = await db.project.update({ where: { id: projectId }, data: restorable });
  await logActivity({ projectId, userId: session.user.id, action: "restoredVersion:" + versionId });
  revalidatePath("/admin/projects");
  revalidatePath(`/admin/projects/${projectId}`);
  return updated;
}

const EDITABLE_FIELDS = [
  "title",
  "slug",
  "titleAccent",
  "categoryId",
  "year",
  "software",
  "client",
  "video",
  "closedMessage",
  "scheduledAt",
  "description",
  "coverId",
  "tags",
  "seoTitle",
  "seoDescription",
] as const;

type EditableProjectInput = Partial<Record<(typeof EDITABLE_FIELDS)[number], unknown>>;

/** General field update for the editor form. Slug uniqueness re-checked server-side. */
export async function updateProject(projectId: string, input: EditableProjectInput) {
  const session = await requireSession();
  requirePermission(session.user.role, "content:write");

  if (typeof input.slug === "string") {
    const { available } = await checkSlugAvailable(input.slug, projectId);
    if (!available) throw new Error("Slug already in use");
  }

  await snapshotVersion(projectId, "Before edit");

  const data: Record<string, unknown> = {};
  for (const field of EDITABLE_FIELDS) {
    if (field in input) data[field] = input[field];
  }
  if (typeof data.scheduledAt === "string") {
    data.scheduledAt = data.scheduledAt ? new Date(data.scheduledAt as string) : null;
  }

  const updated = await db.project.update({ where: { id: projectId }, data });
  await logActivity({ projectId, userId: session.user.id, action: "edited" });
  revalidatePath("/admin/projects");
  revalidatePath(`/admin/projects/${projectId}`);
  revalidatePath(`/projects/${updated.slug}`);
  return updated;
}

/** Export one or more projects as JSON (admin-only, full fields except passwordHash). */
export async function exportProjectsJson(projectIds: string[]) {
  const session = await requireSession();
  requirePermission(session.user.role, "content:read");

  const projects = await db.project.findMany({
    where: { id: { in: projectIds } },
    include: { category: true, cover: true, gallery: { include: { media: true } }, links: true, files: true },
  });
  return projects.map(({ passwordHash, ...p }) => p);
}

export type AdminProjectFilters = {
  status?: ProjectStatus;
  visibility?: ProjectVisibility;
  categoryId?: string;
  featuredOnly?: boolean;
  trashed?: boolean; // true = Trash view, false/undefined = active list
  page?: number; // 1-based
  pageSize?: number;
};

/**
 * Paginated admin read (the spec requires paginating any list that can
 * grow rather than loading everything client-side). Excludes passwordHash
 * even for admins; exposes only whether one is set.
 */
export async function getAdminProjects(filters: AdminProjectFilters = {}) {
  const session = await requireSession();
  requirePermission(session.user.role, "content:read");

  const page = Math.max(1, filters.page ?? 1);
  const pageSize = Math.min(100, Math.max(1, filters.pageSize ?? 25));

  const where = {
    trashedAt: filters.trashed ? { not: null } : null,
    ...(filters.status ? { status: filters.status } : {}),
    ...(filters.visibility ? { visibility: filters.visibility } : {}),
    ...(filters.categoryId ? { categoryId: filters.categoryId } : {}),
    ...(filters.featuredOnly ? { featured: true } : {}),
  };

  const [total, projects] = await Promise.all([
    db.project.count({ where }),
    db.project.findMany({
      where,
      orderBy: { updatedAt: "desc" },
      include: { category: true, cover: true },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
  ]);

  return {
    total,
    page,
    pageSize,
    projects: projects.map(({ passwordHash, ...p }) => ({ ...p, hasPassword: !!passwordHash })),
  };
}
