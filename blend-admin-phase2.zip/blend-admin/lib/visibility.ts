import type { Project, ProjectStatus, ProjectVisibility } from "@prisma/client";

/**
 * Single source of truth for the status/visibility lifecycle described in
 * the spec (Section 4). Everything that decides "can an unauthenticated
 * visitor see this" — the public project list query, the project detail
 * route, sitemap.xml generation, and robots meta — calls into these
 * functions, so they can never drift out of sync with each other.
 */

/** A SCHEDULED project becomes effectively PUBLISHED once scheduledAt has passed. */
export function effectiveStatus(project: Pick<Project, "status" | "scheduledAt">): ProjectStatus {
  if (project.status === "SCHEDULED" && project.scheduledAt && project.scheduledAt <= new Date()) {
    return "PUBLISHED";
  }
  return project.status;
}

/** True only for status=PUBLISHED (or scheduled-and-due) AND visibility=PUBLIC. */
export function isIndexable(project: Pick<Project, "status" | "scheduledAt" | "visibility">): boolean {
  return effectiveStatus(project) === "PUBLISHED" && project.visibility === "PUBLIC";
}

/** robots meta content for a given project — SEO must always match reality. */
export function robotsMeta(project: Pick<Project, "status" | "scheduledAt" | "visibility">): string {
  return isIndexable(project) ? "index, follow" : "noindex, nofollow";
}

/**
 * Whether a project is visible to an unauthenticated public request at all
 * (as opposed to indexable — an unlisted-but-published project is visible
 * via direct link but not indexable).
 */
export function isPubliclyReachable(
  project: Pick<Project, "status" | "scheduledAt" | "visibility">
): boolean {
  const status = effectiveStatus(project);
  if (status !== "PUBLISHED") return false;
  return project.visibility === "PUBLIC" || project.visibility === "UNLISTED";
  // PRIVATE -> never reachable without an authenticated admin session.
  // PASSWORD_PROTECTED -> reachable only after the visitor supplies the
  //   correct password (checked server-side, see lib/password-gate.ts).
}

/**
 * Prisma `where` fragment for "everything a public, unauthenticated caller
 * is allowed to receive." Use this in every public-facing query instead of
 * hand-rolling status/visibility conditions, so there is exactly one place
 * that defines "public" and the payload can never include draft/private/
 * trashed content by accident.
 *
 * Note this only handles PUBLIC + UNLISTED + already-due SCHEDULED
 * projects. PASSWORD_PROTECTED projects still match this filter (they ARE
 * publicly reachable, just gated) — the password check happens separately,
 * server-side, before the project body is returned. See lib/password-gate.ts.
 */
export function publicProjectWhere() {
  const now = new Date();
  return {
    trashedAt: null,
    OR: [
      { status: "PUBLISHED" as ProjectStatus, visibility: { in: ["PUBLIC", "UNLISTED", "PASSWORD_PROTECTED"] as ProjectVisibility[] } },
      { status: "SCHEDULED" as ProjectStatus, scheduledAt: { lte: now }, visibility: { in: ["PUBLIC", "UNLISTED", "PASSWORD_PROTECTED"] as ProjectVisibility[] } },
    ],
  };
}

/** Prisma `where` fragment for sitemap.xml — indexable projects only. */
export function sitemapProjectWhere() {
  const now = new Date();
  return {
    trashedAt: null,
    visibility: "PUBLIC" as ProjectVisibility,
    OR: [
      { status: "PUBLISHED" as ProjectStatus },
      { status: "SCHEDULED" as ProjectStatus, scheduledAt: { lte: now } },
    ],
  };
}
