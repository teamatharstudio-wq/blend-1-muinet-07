import NextAuth from "next-auth";
import type { NextAuthConfig } from "next-auth";

/**
 * FLAGGED SUBSTITUTION / PLATFORM CONSTRAINT:
 * NextAuth v5's database session strategy needs the Prisma adapter, and
 * Prisma's query engine is not edge-runtime compatible, so it cannot run
 * inside `middleware.ts` (which executes on the edge runtime by default).
 *
 * Standard, documented NextAuth v5 pattern for this: a *separate*, adapter-
 * free config used only in middleware to read the session cookie and do a
 * coarse "is there a session at all" redirect (logged-out -> /login).
 *
 * This is a UX convenience only. It is NOT the authorization boundary.
 * Every Server Action and Route Handler re-verifies the real session
 * (lib/auth.ts -> requireSession) and the caller's role (lib/rbac.ts ->
 * requirePermission) against the database on every single mutation,
 * regardless of what middleware already checked. Middleware being bypassed,
 * misconfigured, or skipped can therefore never expose an unauthorized
 * write or an unauthorized read of private data.
 */
const edgeAuthConfig: NextAuthConfig = {
  providers: [], // not used to authenticate here, only to read the cookie/session shape
  session: { strategy: "database" },
  pages: { signIn: "/login" },
};

export const { auth: edgeAuth } = NextAuth(edgeAuthConfig);
