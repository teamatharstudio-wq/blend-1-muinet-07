import "server-only";

/**
 * FLAGGED SUBSTITUTION:
 * This is an in-memory rate limiter. It works correctly on a single
 * long-lived Node server, but on serverless/edge platforms (Vercel, etc.)
 * each invocation can get a cold instance with its own memory, so limits
 * won't be enforced consistently across requests.
 *
 * For a real deployment, swap this for a shared store — Upstash Redis is
 * the common pairing with Vercel (`@upstash/ratelimit` + `@upstash/redis`),
 * or any Redis instance you already run. The call sites (contact form
 * action, password-gate action) are written against this same
 * `checkRateLimit()` signature, so swapping the implementation in this
 * file is the only change needed.
 */

type Bucket = { count: number; resetAt: number };
const buckets = new Map<string, Bucket>();

export function checkRateLimit(
  key: string,
  { limit, windowMs }: { limit: number; windowMs: number }
): { ok: boolean; remaining: number } {
  const now = Date.now();
  const existing = buckets.get(key);

  if (!existing || existing.resetAt <= now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return { ok: true, remaining: limit - 1 };
  }

  if (existing.count >= limit) {
    return { ok: false, remaining: 0 };
  }

  existing.count += 1;
  return { ok: true, remaining: limit - existing.count };
}
