import "server-only";
import bcrypt from "bcryptjs";

const SALT_ROUNDS = 12;

/** Hash a plaintext password server-side. Never call this from client code. */
export async function hashPassword(plaintext: string): Promise<string> {
  return bcrypt.hash(plaintext, SALT_ROUNDS);
}

/** Compare a plaintext guess against a stored hash server-side. */
export async function verifyPassword(plaintext: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plaintext, hash);
}
