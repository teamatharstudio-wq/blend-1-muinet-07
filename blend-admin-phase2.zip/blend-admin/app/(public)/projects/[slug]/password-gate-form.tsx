"use client";

import { useState, useTransition } from "react";
import { unlockProject } from "@/lib/actions/password-gate";

export default function PasswordGateForm({ slug }: { slug: string }) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [unlocked, setUnlocked] = useState<Awaited<ReturnType<typeof unlockProject>> | null>(null);
  const [isPending, startTransition] = useTransition();

  function submit() {
    setError("");
    startTransition(async () => {
      const result = await unlockProject(slug, password);
      if (!result.ok) {
        setError(result.reason === "rate_limited" ? "Too many attempts — try again later." : "Incorrect password.");
        return;
      }
      setUnlocked(result);
    });
  }

  if (unlocked?.ok) {
    return (
      <div>
        <h2 className="text-lg font-medium">{unlocked.project.title}</h2>
        {unlocked.project.description && <p className="mt-2 whitespace-pre-line">{unlocked.project.description}</p>}
        <div className="mt-4 grid grid-cols-2 gap-3">
          {unlocked.project.gallery.map((g) => (
            <img key={g.id} src={g.media.url} alt={g.media.name ?? ""} className="rounded" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-2">
      <input
        type="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        placeholder="Password"
        className="rounded border px-3 py-2"
        onKeyDown={(e) => e.key === "Enter" && submit()}
      />
      <button disabled={isPending} onClick={submit} className="rounded bg-black px-3 py-2 text-sm text-white">
        Unlock
      </button>
      {error && <p className="text-sm text-red-600">{error}</p>}
    </div>
  );
}
