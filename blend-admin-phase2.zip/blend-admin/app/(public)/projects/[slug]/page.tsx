import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { getPublicProjectBySlug } from "@/lib/queries/projects-public";
import { robotsMeta } from "@/lib/visibility";
import PasswordGateForm from "./password-gate-form";

export const revalidate = 30;

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const project = await getPublicProjectBySlug(params.slug);
  if (!project) return {};
  return {
    title: project.seoTitle || project.title,
    description: project.seoDescription || undefined,
    robots: robotsMeta(project),
  };
}

export default async function ProjectDetailPage({ params }: { params: { slug: string } }) {
  const project = await getPublicProjectBySlug(params.slug);
  if (!project) notFound();

  if (project.status === "CLOSED") {
    return (
      <main className="mx-auto max-w-2xl p-6">
        <h1 className="text-2xl font-semibold">{project.title}</h1>
        <p className="mt-4 text-gray-500">{project.closedMessage || "This project is no longer available."}</p>
      </main>
    );
  }

  if (project.locked) {
    return (
      <main className="mx-auto max-w-md p-6">
        <h1 className="mb-4 text-2xl font-semibold">{project.title}</h1>
        <p className="mb-4 text-sm text-gray-500">This project is password protected.</p>
        <PasswordGateForm slug={params.slug} />
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-4xl p-6">
      <h1 className="text-2xl font-semibold">
        {project.title} {project.titleAccent && <em className="text-gray-400">{project.titleAccent}</em>}
      </h1>
      <p className="text-sm text-gray-500">
        {project.category?.name} · {project.year} · {project.software?.join(", ")}
      </p>
      {project.description && <p className="mt-4 whitespace-pre-line">{project.description}</p>}
      <div className="mt-6 grid grid-cols-2 gap-3">
        {project.gallery.map((g) => (
          <img key={g.id} src={g.media.url} alt={g.media.name} className="rounded" />
        ))}
      </div>
      {project.links.length > 0 && (
        <ul className="mt-6 flex flex-wrap gap-3 text-sm">
          {project.links.map((l) => (
            <li key={l.id}>
              <a href={l.url} target="_blank" rel="noopener noreferrer" className="underline">
                {l.label}
              </a>
            </li>
          ))}
        </ul>
      )}
    </main>
  );
}
