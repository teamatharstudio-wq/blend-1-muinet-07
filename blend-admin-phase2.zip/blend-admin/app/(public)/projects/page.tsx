import Link from "next/link";
import { listPublicProjects } from "@/lib/queries/projects-public";

export const revalidate = 60;

export default async function ProjectsPage({
  searchParams,
}: {
  searchParams: { category?: string };
}) {
  const projects = await listPublicProjects({ category: searchParams.category });

  return (
    <main className="mx-auto max-w-5xl p-6">
      <h1 className="mb-6 text-2xl font-semibold">Projects</h1>
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-3">
        {projects.map((p) => (
          <Link key={p.id} href={`/projects/${p.slug}`} className="group block">
            {p.cover?.url && (
              <img src={p.cover.url} alt={p.title} className="aspect-[4/3] w-full rounded object-cover" />
            )}
            <h2 className="mt-2 font-medium">
              {p.title} {p.titleAccent && <em className="text-gray-400">{p.titleAccent}</em>}
            </h2>
            <p className="text-sm text-gray-500">{p.category?.name}</p>
          </Link>
        ))}
      </div>
    </main>
  );
}
