import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  // Defense in depth: middleware.ts already redirects logged-out visitors,
  // but this Server Component re-checks the real, database-verified
  // session directly, so this layout is safe even if middleware were ever
  // misconfigured, bypassed, or removed.
  const session = await auth();
  if (!session?.user) {
    redirect("/login");
  }

  return (
    <div className="flex min-h-screen">
      <aside className="w-56 border-r p-4 text-sm">
        <div className="mb-6 font-semibold">Blend Admin</div>
        <nav className="flex flex-col gap-2">
          <a href="/admin">Dashboard</a>
          <a href="/admin/projects">Projects</a>
          <a href="/admin/categories">Categories</a>
          <a href="/admin/media">Media</a>
          <a href="/admin/messages">Messages</a>
          <a href="/admin/blog">Blog</a>
          {session.user.role === "OWNER" && <a href="/admin/users">Users &amp; Roles</a>}
          {session.user.role === "OWNER" && <a href="/admin/settings">Settings</a>}
          <a href="/admin/logs">Logs</a>
        </nav>
      </aside>
      <main className="flex-1 p-6">{children}</main>
    </div>
  );
}
