import { db } from "@/lib/db";
import { createProject } from "@/lib/actions/projects-admin";
import { redirect } from "next/navigation";

function slugify(s: string) {
  return s
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

export default async function NewProjectPage() {
  const categories = await db.category.findMany({ orderBy: { name: "asc" } });

  async function create(formData: FormData) {
    "use server";
    const title = String(formData.get("title") || "");
    const categoryId = String(formData.get("categoryId") || "") || undefined;
    const project = await createProject({ title, slug: slugify(title), categoryId });
    redirect(`/admin/projects/${project.id}`);
  }

  return (
    <div className="mx-auto max-w-sm">
      <h1 className="mb-4 text-xl font-semibold">New project</h1>
      <form action={create} className="flex flex-col gap-3">
        <label className="flex flex-col gap-1 text-sm">
          Title
          <input name="title" required className="rounded border px-3 py-2" />
        </label>
        <label className="flex flex-col gap-1 text-sm">
          Category
          <select name="categoryId" className="rounded border px-3 py-2">
            <option value="">—</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </label>
        <button type="submit" className="rounded bg-black px-3 py-2 text-sm text-white">
          Create draft
        </button>
      </form>
    </div>
  );
}
