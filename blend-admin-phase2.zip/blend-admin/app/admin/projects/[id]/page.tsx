import { db } from "@/lib/db";
import { getAdminProjectById, getProjectActivityLog, getProjectVersions } from "@/lib/actions/projects-admin";
import ProjectEditorForm from "./editor-form";

export default async function ProjectEditPage({ params }: { params: { id: string } }) {
  const [project, categories, activity, versions] = await Promise.all([
    getAdminProjectById(params.id),
    db.category.findMany({ orderBy: { name: "asc" } }),
    getProjectActivityLog(params.id),
    getProjectVersions(params.id),
  ]);

  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="mb-4 text-xl font-semibold">Edit: {project.title}</h1>
      <ProjectEditorForm project={project} categories={categories} activity={activity} versions={versions} />
    </div>
  );
}
