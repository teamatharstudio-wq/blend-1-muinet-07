"use client";

import { useState, useTransition } from "react";
import {
  updateProject,
  updateProjectStatus,
  setProjectVisibility,
  setProjectPassword,
  restoreProjectVersion,
} from "@/lib/actions/projects-admin";

type Props = {
  project: any;
  categories: { id: string; name: string }[];
  activity: any[];
  versions: any[];
};

const STATUSES = ["DRAFT", "REVIEW", "SCHEDULED", "PUBLISHED", "ARCHIVED", "CLOSED"];
const VISIBILITIES = ["PUBLIC", "PRIVATE", "PASSWORD_PROTECTED", "UNLISTED"];

export default function ProjectEditorForm({ project, categories, activity, versions }: Props) {
  const [form, setForm] = useState({
    title: project.title ?? "",
    slug: project.slug ?? "",
    titleAccent: project.titleAccent ?? "",
    categoryId: project.categoryId ?? "",
    year: project.year ?? "",
    software: (project.software ?? []).join(", "),
    client: project.client ?? "",
    video: project.video ?? "",
    closedMessage: project.closedMessage ?? "",
    scheduledAt: project.scheduledAt ? new Date(project.scheduledAt).toISOString().slice(0, 16) : "",
    description: project.description ?? "",
    tags: (project.tags ?? []).join(", "),
    seoTitle: project.seoTitle ?? "",
    seoDescription: project.seoDescription ?? "",
  });
  const [status, setStatus] = useState(project.status);
  const [visibility, setVisibility] = useState(project.visibility);
  const [newPassword, setNewPassword] = useState("");
  const [saveMessage, setSaveMessage] = useState("");
  const [isPending, startTransition] = useTransition();

  function field<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function save() {
    await updateProject(project.id, {
      title: form.title,
      slug: form.slug,
      titleAccent: form.titleAccent || null,
      categoryId: form.categoryId || null,
      year: form.year || null,
      software: form.software.split(",").map((s) => s.trim()).filter(Boolean),
      client: form.client || null,
      video: form.video || null,
      closedMessage: form.closedMessage || null,
      scheduledAt: form.scheduledAt || null,
      description: form.description || null,
      tags: form.tags.split(",").map((s) => s.trim()).filter(Boolean),
      seoTitle: form.seoTitle || null,
      seoDescription: form.seoDescription || null,
    });
    setSaveMessage("Saved");
    setTimeout(() => setSaveMessage(""), 2000);
  }

  return (
    <div className="flex flex-col gap-8">
      <section className="flex flex-col gap-3">
        <Field label="Title"><input className="input" value={form.title} onChange={(e) => field("title", e.target.value)} /></Field>
        <Field label="Slug"><input className="input" value={form.slug} onChange={(e) => field("slug", e.target.value)} /></Field>
        <Field label="Title accent"><input className="input" value={form.titleAccent} onChange={(e) => field("titleAccent", e.target.value)} /></Field>
        <Field label="Category">
          <select className="input" value={form.categoryId} onChange={(e) => field("categoryId", e.target.value)}>
            <option value="">—</option>
            {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </Field>
        <Field label="Year"><input className="input" value={form.year} onChange={(e) => field("year", e.target.value)} /></Field>
        <Field label="Software (comma separated)"><input className="input" value={form.software} onChange={(e) => field("software", e.target.value)} /></Field>
        <Field label="Client"><input className="input" value={form.client} onChange={(e) => field("client", e.target.value)} /></Field>
        <Field label="Video URL"><input className="input" value={form.video} onChange={(e) => field("video", e.target.value)} /></Field>
        <Field label="Description"><textarea className="input" rows={4} value={form.description} onChange={(e) => field("description", e.target.value)} /></Field>
        <Field label="Tags (comma separated)"><input className="input" value={form.tags} onChange={(e) => field("tags", e.target.value)} /></Field>
        <Field label="SEO title"><input className="input" value={form.seoTitle} onChange={(e) => field("seoTitle", e.target.value)} /></Field>
        <Field label="SEO description"><textarea className="input" rows={2} value={form.seoDescription} onChange={(e) => field("seoDescription", e.target.value)} /></Field>
        <Field label="Closed message (shown when status = CLOSED)"><input className="input" value={form.closedMessage} onChange={(e) => field("closedMessage", e.target.value)} /></Field>
        <Field label="Scheduled at (used when status = SCHEDULED)">
          <input className="input" type="datetime-local" value={form.scheduledAt} onChange={(e) => field("scheduledAt", e.target.value)} />
        </Field>

        <div className="flex items-center gap-3">
          <button disabled={isPending} onClick={() => startTransition(save)} className="rounded bg-black px-4 py-2 text-sm text-white">
            Save
          </button>
          {saveMessage && <span className="text-sm text-green-600">{saveMessage}</span>}
        </div>
      </section>

      <section className="flex flex-col gap-3 border-t pt-4">
        <h2 className="font-semibold">Lifecycle</h2>
        <Field label="Status">
          <select
            className="input"
            value={status}
            onChange={(e) => {
              setStatus(e.target.value);
              startTransition(() => updateProjectStatus(project.id, e.target.value as any));
            }}
          >
            {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        </Field>
        <Field label="Visibility (applies once status = PUBLISHED)">
          <select
            className="input"
            value={visibility}
            onChange={(e) => {
              setVisibility(e.target.value);
              startTransition(() => setProjectVisibility(project.id, e.target.value as any));
            }}
          >
            {VISIBILITIES.map((v) => <option key={v} value={v}>{v}</option>)}
          </select>
        </Field>

        {visibility === "PASSWORD_PROTECTED" && (
          <Field label={project.hasPassword ? "Change password" : "Set password"}>
            <div className="flex gap-2">
              <input
                className="input"
                type="text"
                placeholder="New password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
              />
              <button
                className="rounded border px-3 py-1 text-sm"
                onClick={() => {
                  if (!newPassword) return;
                  startTransition(() => setProjectPassword(project.id, newPassword));
                  setNewPassword("");
                }}
              >
                Set
              </button>
              {project.hasPassword && (
                <button
                  className="rounded border px-3 py-1 text-sm text-red-600"
                  onClick={() => startTransition(() => setProjectPassword(project.id, null))}
                >
                  Clear
                </button>
              )}
            </div>
          </Field>
        )}
      </section>

      <section className="flex flex-col gap-2 border-t pt-4">
        <h2 className="font-semibold">Version history</h2>
        {versions.length === 0 && <p className="text-sm text-gray-400">No versions yet.</p>}
        <ul className="flex flex-col gap-1 text-sm">
          {versions.map((v) => (
            <li key={v.id} className="flex items-center justify-between">
              <span>{new Date(v.ts).toLocaleString()} — {v.note}</span>
              <button
                className="text-blue-600"
                onClick={() => {
                  if (confirm("Restore this version? Current field values will be overwritten (a snapshot of the current state is taken first).")) {
                    startTransition(() => restoreProjectVersion(project.id, v.id));
                  }
                }}
              >
                Restore
              </button>
            </li>
          ))}
        </ul>
      </section>

      <section className="flex flex-col gap-2 border-t pt-4">
        <h2 className="font-semibold">Activity log</h2>
        <ul className="flex flex-col gap-1 text-sm text-gray-600">
          {activity.map((a) => (
            <li key={a.id}>
              {new Date(a.ts).toLocaleString()} — {a.user?.name || a.user?.email} — {a.action}
              {a.prevStatus && a.newStatus ? ` (${a.prevStatus} → ${a.newStatus})` : ""}
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="flex flex-col gap-1 text-sm">
      <span className="text-gray-600">{label}</span>
      {children}
    </label>
  );
}
