"use client";

import { useState, useTransition } from "react";
import Link from "next/link";
import {
  toggleFeatured,
  trashProject,
  restoreProject,
  permanentlyDeleteProject,
  duplicateProject,
  bulkTrash,
  bulkUpdateCategory,
  bulkAddTag,
} from "@/lib/actions/projects-admin";

type Row = {
  id: string;
  title: string;
  slug: string;
  status: string;
  visibility: string;
  featured: boolean;
  hasPassword: boolean;
  category: { id: string; name: string } | null;
};

export default function ProjectListClient({
  projects,
  categories,
  isTrashView,
}: {
  projects: Row[];
  categories: { id: string; name: string }[];
  isTrashView: boolean;
}) {
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [isPending, startTransition] = useTransition();

  function toggleSelect(id: string) {
    setSelected((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }

  const selectedIds = Array.from(selected);

  return (
    <div className="flex flex-col gap-3">
      {selectedIds.length > 0 && (
        <div className="flex flex-wrap items-center gap-2 rounded border bg-gray-50 p-2 text-sm">
          <span>{selectedIds.length} selected</span>
          {!isTrashView && (
            <>
              <select
                className="rounded border px-2 py-1"
                defaultValue=""
                onChange={(e) => {
                  if (!e.target.value) return;
                  startTransition(() => bulkUpdateCategory(selectedIds, e.target.value));
                }}
              >
                <option value="">Change category&hellip;</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
              <button
                className="rounded border px-2 py-1"
                onClick={() => {
                  const tag = prompt("Tag to add:");
                  if (tag) startTransition(() => bulkAddTag(selectedIds, tag));
                }}
              >
                Add tag
              </button>
              <button
                className="rounded border px-2 py-1 text-red-600"
                onClick={() => startTransition(() => bulkTrash(selectedIds))}
              >
                Trash selected
              </button>
            </>
          )}
        </div>
      )}

      <table className="w-full text-left text-sm">
        <thead>
          <tr className="border-b text-gray-500">
            <th className="w-6"></th>
            <th className="py-2">Title</th>
            <th>Status</th>
            <th>Visibility</th>
            <th>Category</th>
            <th>Featured</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {projects.map((p) => (
            <tr key={p.id} className="border-b">
              <td>
                <input type="checkbox" checked={selected.has(p.id)} onChange={() => toggleSelect(p.id)} />
              </td>
              <td className="py-2">
                <Link href={`/admin/projects/${p.id}`} className="font-medium">{p.title}</Link>
                {p.hasPassword && <span className="ml-2 text-xs text-gray-400">(password)</span>}
              </td>
              <td>{p.status}</td>
              <td>{p.visibility}</td>
              <td>{p.category?.name ?? "—"}</td>
              <td>
                <button
                  disabled={isPending}
                  onClick={() => startTransition(() => toggleFeatured(p.id, !p.featured))}
                >
                  {p.featured ? "★" : "☆"}
                </button>
              </td>
              <td className="flex gap-2 py-2 text-xs">
                {isTrashView ? (
                  <>
                    <button onClick={() => startTransition(() => restoreProject(p.id))}>Restore</button>
                    <button
                      className="text-red-600"
                      onClick={() => {
                        if (confirm(`Permanently delete "${p.title}"? This cannot be undone.`)) {
                          startTransition(() => permanentlyDeleteProject(p.id));
                        }
                      }}
                    >
                      Delete forever
                    </button>
                  </>
                ) : (
                  <>
                    <button onClick={() => startTransition(() => duplicateProject(p.id))}>Duplicate</button>
                    <button className="text-red-600" onClick={() => startTransition(() => trashProject(p.id))}>
                      Trash
                    </button>
                  </>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
