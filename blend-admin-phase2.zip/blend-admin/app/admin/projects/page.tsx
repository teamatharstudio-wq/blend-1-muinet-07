import Link from "next/link";
import { getAdminProjects } from "@/lib/actions/projects-admin";
import { db } from "@/lib/db";
import type { ProjectStatus, ProjectVisibility } from "@prisma/client";
import ProjectListClient from "./project-list-client";

export default async function ProjectsAdminPage({
  searchParams,
}: {
  searchParams: {
    status?: ProjectStatus;
    visibility?: ProjectVisibility;
    categoryId?: string;
    featured?: string;
    trashed?: string;
    page?: string;
  };
}) {
  const [{ projects, total, page, pageSize }, categories] = await Promise.all([
    getAdminProjects({
      status: searchParams.status,
      visibility: searchParams.visibility,
      categoryId: searchParams.categoryId,
      featuredOnly: searchParams.featured === "1",
      trashed: searchParams.trashed === "1",
      page: searchParams.page ? Number(searchParams.page) : 1,
    }),
    db.category.findMany({ orderBy: { name: "asc" } }),
  ]);

  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold">
          {searchParams.trashed === "1" ? "Trash" : "Projects"} <span className="text-gray-400">({total})</span>
        </h1>
        <Link href="/admin/projects/new" className="rounded bg-black px-3 py-2 text-sm text-white">
          New project
        </Link>
      </div>

      <form className="flex flex-wrap gap-2 text-sm" method="get">
        <select name="status" defaultValue={searchParams.status ?? ""} className="rounded border px-2 py-1">
          <option value="">All statuses</option>
          {["DRAFT", "REVIEW", "SCHEDULED", "PUBLISHED", "ARCHIVED", "CLOSED"].map((s) => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>
        <select name="visibility" defaultValue={searchParams.visibility ?? ""} className="rounded border px-2 py-1">
          <option value="">All visibilities</option>
          {["PUBLIC", "PRIVATE", "PASSWORD_PROTECTED", "UNLISTED"].map((v) => (
            <option key={v} value={v}>{v}</option>
          ))}
        </select>
        <select name="categoryId" defaultValue={searchParams.categoryId ?? ""} className="rounded border px-2 py-1">
          <option value="">All categories</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </select>
        <label className="flex items-center gap-1">
          <input type="checkbox" name="featured" value="1" defaultChecked={searchParams.featured === "1"} />
          Featured only
        </label>
        <label className="flex items-center gap-1">
          <input type="checkbox" name="trashed" value="1" defaultChecked={searchParams.trashed === "1"} />
          Trash
        </label>
        <button type="submit" className="rounded border px-3 py-1">Apply</button>
      </form>

      <ProjectListClient projects={projects} categories={categories} isTrashView={searchParams.trashed === "1"} />

      <div className="flex gap-2 text-sm">
        {page > 1 && <Link href={`?page=${page - 1}`}>&larr; Prev</Link>}
        <span>Page {page} of {totalPages}</span>
        {page < totalPages && <Link href={`?page=${page + 1}`}>Next &rarr;</Link>}
      </div>
    </div>
  );
}
