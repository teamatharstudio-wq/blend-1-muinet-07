/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    // Add your S3-compatible public bucket hostname here once configured.
    remotePatterns: [],
  },
};

export default nextConfig;
