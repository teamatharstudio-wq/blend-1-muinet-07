import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const db = new PrismaClient();

async function main() {
  const ownerEmail = process.env.SEED_OWNER_EMAIL;
  const ownerPassword = process.env.SEED_OWNER_PASSWORD;

  if (!ownerEmail || !ownerPassword) {
    throw new Error(
      "Set SEED_OWNER_EMAIL and SEED_OWNER_PASSWORD env vars before running the seed " +
        "(e.g. `SEED_OWNER_EMAIL=you@example.com SEED_OWNER_PASSWORD='...' npm run seed`). " +
        "Never hardcode credentials in this file."
    );
  }

  const passwordHash = await bcrypt.hash(ownerPassword, 12);

  await db.user.upsert({
    where: { email: ownerEmail.toLowerCase() },
    update: {},
    create: { email: ownerEmail.toLowerCase(), passwordHash, role: "OWNER", name: "Owner" },
  });

  await db.settings.upsert({
    where: { id: "singleton" },
    update: {},
    create: {
      id: "singleton",
      siteName: "Blend 1 Minute",
      tagline: "3D Modeling · Product Visualization · Rendering · CGI · Motion",
      email: "teamatharstudio@outlook.com",
      seoTitle: "Blend 1 Minute — 3D & CGI Studio",
      seoDescription: "Premium 3D modeling, product visualization, rendering, CGI and motion studio.",
      trashRetentionDays: 30,
    },
  });

  const categoryNames = ["Product Visualization", "CGI", "Rendering", "Motion"];
  for (const name of categoryNames) {
    await db.category.upsert({ where: { name }, update: {}, create: { name } });
  }

  console.log(`Seeded Owner user: ${ownerEmail}`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
