# Blend 1 Minute — Admin Dashboard (Phase 1: Foundation)

This is the security/data foundation for the production admin dashboard
described in the spec. It replaces every "known-bad pattern" from the
`blend-one-minute-visibility.jsx` prototype:

| Prototype problem | Fixed here |
|---|---|
| Everything (including private content + passwords) lived in one client-readable `window.storage` blob | All data lives in PostgreSQL via Prisma; public queries (`lib/queries/projects-public.ts`) only ever `select` fields safe for an unauthenticated caller |
| `password` stored and compared in plaintext | `passwordHash` column, bcrypt (cost 12) hash/compare in `lib/passwords.ts`, never sent to the client |
| Admin access = a checkbox (`<input type="checkbox" checked={isAdmin} .../>`) | Real credentials auth (NextAuth v5), database-backed sessions, secure/httpOnly/sameSite cookie, verified server-side on every request |
| No file persistence (`URL.createObjectURL`) | Media Library schema + `.env` wired for real S3-compatible object storage (Phase 3 will add the upload route) |

## What's in Phase 1

- `prisma/schema.prisma` — the full data model from the spec (Project,
  Category, MediaAsset, BlogPost, User/Role, Settings, ActivityLogEntry,
  VersionSnapshot) plus NextAuth's required tables.
- `lib/auth.ts` / `lib/auth.edge.ts` — real authentication.
- `lib/rbac.ts` — Owner/Editor/Viewer permission matrix, used identically
  by every Server Action.
- `middleware.ts` — coarse logged-out redirect for `/admin/*`.
- `lib/visibility.ts` — the one place that defines "public" (status +
  visibility + scheduling), used by both the public queries and (in a
  later phase) `sitemap.xml`/robots meta, so they can't drift apart.
- `lib/queries/projects-public.ts` — public reads, explicit `select`
  allow-lists (no passwordHash, no activityLog, no versions).
- `lib/actions/projects-admin.ts` — admin writes. Every function calls
  `requireSession()` then `requirePermission(role, ...)` before touching
  the database, and writes an append-only `ActivityLogEntry`.
- `lib/actions/password-gate.ts` — server-side password check for
  password-protected projects, rate-limited.
- `prisma/seed.ts` — bootstraps the first Owner user (no hardcoded
  credentials — pass them as env vars when you run it).

## Running it

```bash
cp .env.example .env        # fill in DATABASE_URL and AUTH_SECRET at minimum
npm install
npx auth secret              # writes AUTH_SECRET into .env if you skip the manual step
npm run prisma:migrate       # creates the schema in Postgres
SEED_OWNER_EMAIL=you@example.com SEED_OWNER_PASSWORD='choose-a-strong-one' npm run seed
npm run dev
```

Then sign in at `/login` with the seeded Owner account. `/admin` is
protected; visiting it while logged out redirects to `/login`.

## Flagged substitutions (per Section 2/10 of the spec)

1. **Middleware can't do real RBAC.** Prisma's query engine isn't
   edge-runtime compatible, so `middleware.ts` only does a coarse
   "is there a session at all" redirect using an adapter-free NextAuth
   config (`lib/auth.edge.ts`). The actual authorization boundary is in
   every Server Action (`requireSession()` + `requirePermission()`) and
   in `app/admin/layout.tsx`, both of which re-verify against the real
   database session on every request. This means the security guarantee
   ("no unauthorized read/write") does not depend on middleware at all —
   see the comments in `lib/auth.edge.ts` and `middleware.ts` for detail.
2. **Rate limiting is in-memory** (`lib/rate-limit.ts`). Fine for a single
   long-lived server; on serverless/edge deploys, swap in Upstash Redis
   (env vars already scaffolded in `.env.example`) — the function
   signature is designed so only that one file changes.
3. **Object storage, Analytics, and Monitoring** are schema/env-ready but
   not wired to a specific provider yet, per the spec's "clearly-labeled
   placeholder, never fabricated numbers" instruction — these land in
   Phase 3 along with the Media Library upload route.

## Phase 2 (added)

- **`app/admin/projects/`** — paginated, filterable list (status,
  visibility, category, featured, trash) with bulk actions (change
  category, add tag, trash) and per-row actions (feature/unfeature,
  duplicate, trash/restore, permanently delete). Backed by the new
  filtering/pagination in `getAdminProjects()` and the bulk/duplicate/
  export/permanent-delete actions in `lib/actions/projects-admin.ts`.
- **`app/admin/projects/[id]/`** — full editor: every field from the spec,
  status + visibility controls (with server-side password set/change for
  PASSWORD_PROTECTED), version history with one-click restore (which
  itself snapshots the pre-restore state first, so a restore is
  undoable), and the per-project activity log.
- **`app/(public)/projects/`** — public list + detail pages, reading only
  from `lib/queries/projects-public.ts` (the allow-listed, no-passwordHash
  query layer from Phase 1). The detail page's `generateMetadata` pulls
  `robots` straight from `lib/visibility.ts` — the exact same function
  the sitemap uses — so indexability can't drift between the two.
  Password-protected projects render a gate form that calls
  `lib/actions/password-gate.ts`; the plaintext password never leaves the
  browser except inside that one Server Action call, and the hash never
  leaves the server at all.
- **`app/sitemap.ts` / `app/robots.ts`** — Next.js's built-in metadata
  routes, generated from `listSitemapProjects()` (PUBLIC + due-SCHEDULED
  only) so the sitemap can never list a draft/private/unlisted project.

## Not yet built (next phase)

- **Phase 3:** Categories admin, Media Library (real S3 upload route +
  "still referenced" delete warning), Messages inbox + rate-limited
  contact form, Blog/CMS, Users & Roles admin UI (including the invite
  stub), site Settings page, Featured-order drag-to-reorder UI (the
  `updateFeaturedOrder` action already exists from Phase 2), Logs viewer,
  Backups, Developer Tools, Analytics wiring.

No placeholder/TODO code exists in what's listed above as "built" — the
"Not yet built" list is the honest accounting of what's intentionally
excluded so far.
