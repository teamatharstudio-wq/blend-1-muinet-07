import { NextResponse } from "next/server";
import { edgeAuth } from "@/lib/auth.edge";

export default edgeAuth((req) => {
  const isAdminRoute = req.nextUrl.pathname.startsWith("/admin");
  const isLoggedIn = !!req.auth?.user;

  if (isAdminRoute && !isLoggedIn) {
    const loginUrl = new URL("/login", req.nextUrl.origin);
    loginUrl.searchParams.set("callbackUrl", req.nextUrl.pathname);
    return NextResponse.redirect(loginUrl);
  }

  // Role-specific route gating (e.g. /admin/users, /admin/settings being
  // Owner-only) is intentionally NOT done here with a role check, because
  // this file cannot see a fresh, adapter-verified role on the edge
  // runtime (see lib/auth.edge.ts). Those routes fetch data via Server
  // Components / Server Actions that call requireSession() +
  // requirePermission() against the real database session, and will
  // refuse to render/return privileged data for the wrong role even if a
  // Viewer manually navigates to the URL.

  return NextResponse.next();
});

export const config = {
  matcher: ["/admin/:path*"],
};
